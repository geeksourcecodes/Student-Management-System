<?php
$query="select * from users where user_id='$session_id'";
$dash = $conn ->query($query);
$row=mysqli_fetch_array($dash);

 ?>

			<div class="life-side-bar" >
			<div class="hero-container" style="width: 200px">                  
					<ul class="nav nav-tabs nav-stacked" style="width: 200px">
						<div style="border:1px solid black;width: 198px">
							<li>
						<center><img height="100"  width="154" style="margin: 5px 0px 0px 3px;" src="../<?php echo $row['photo'];?>">
							

						<br>
						<strong class="name1"><?php echo $row['firstname']." ".$row['lastname']; ?><br>
						<?php echo $row['user_type'] ?>
						</strong></center>
							</li>
						</div>


						<li class="">
						<a href="dasboard.php" class="yellow_link"><i class="icon-list icon-large icon-large"></i>&nbsp;Dashboard</a>
						</li>

					
						<li class="">
						<a href="grades.php" class="yellow_link"><i class="icon-list icon-large icon-large"></i>&nbsp;Manage Grades</a>
						</li>

						<li class="">
							<a href="activity.php" class="yellow_link"><i class="icon-home icon-large icon-large"></i>&nbsp;Manage Announcement</a>
						</li>


						<li class="">
						<a href="logout.php" class="yellow_link"><i class="icon-signout icon-large"></i>&nbsp;Logout</a>
						</li>
							
					</ul>
			</div>
			

			</div>
	