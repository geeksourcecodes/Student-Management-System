		<div class="span12">
				<div class="header111">
				<div class="pull-left" style="height:140px">
					<img class="stilogo" src="../image/head.jpg" width="1170" height="150" min-width="800">
				</div>
				</div>
					<div class="alert alert-success"> 
						<strong>Heads Up!</strong>&nbsp;Welcome to CHMBAC STUDENT MANAGEMENT SYSTEM
							<div class="pull-right">
								<i class="icon-calendar icon-large"></i>
								<?php
								$Today = date('y:m:d');
								$new = date('l, F d, Y', strtotime($Today));
								echo $new;
								?>
							</div>
					</div>
				</div>