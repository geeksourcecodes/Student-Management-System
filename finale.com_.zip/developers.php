<?php include('header.php'); ?>


    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head1.php'); ?>
		
				<div class="span12">
					developers information
				</div>
			
				
			</div>
		</div>
    </div>
<?php include('footer.php') ?>