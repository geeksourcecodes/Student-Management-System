<?php include('header.php'); ?>

    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head1.php'); ?>
				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
				<iframe width="970" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com.ph/maps/place/Pangasinan+State+University,+San+Carlos+City+Campus/@15.9336241,120.3403076,15z/data=!4m5!3m4!1s0x0:0xf864dc30996e9900!8m2!3d15.9336241!4d120.3403076"></iframe><br /><small><a href="https://www.google.com.ph/maps/place/Pangasinan+State+University,+San+Carlos+City+Campus/@15.9336241,120.3403076,15z/data=!4m5!3m4!1s0x0:0xf864dc30996e9900!8m2!3d15.9336241!4d120.3403076" style="color:#0000FF;text-align:left">View Larger Map</a></small>
				</div>
			</div>
		</div>
    </div>
<?php include('footer.php') ?>
