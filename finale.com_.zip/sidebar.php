			<div class="life-side-bar">
			<div class="hero-container">                  
					<ul class="nav nav-tabs nav-stacked">
						<li class="active">
							<a href="index.php" class="yellow_link"><i class="icon-home icon-large icon-large"></i>&nbsp;Home</a>
						</li>
					
					
						<li><a  class="yellow_link" href="sitemap.php"><i class="icon-sitemap icon-large"></i>&nbsp;Site Map</a></li>
					</ul>
			</div>
			
			<p><img src="image/ust_seal.png" alt="" width="200" class="img-polaroid"/></p>
		
					<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a  href="#"><i class="icon-phone icon-large"></i>&nbsp;Programs</a>
						</li>
						<p></p>
							<p>Bachelor of Science in Information Technology</p>
							<p>Bachelor of Science in Business Administration</p>
							<p>Bachelor of Science in Hospitality Management</p>
							<p>Bachelor of Science in Office Administration</p>
					</ul>

					
							<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a   href="#"><i class="icon-phone icon-large"></i>&nbsp;Contact US</a>
						</li>
					</ul>
<strong>Address</strong>
<p>UST</p>
<p>Tel. nos.:</p>
<p>(075) 532-2235</p>
<p>Website:
<p><a href="http://www.psu.edu.ph">http://www.psu.edu.ph</a></p>
			
			</div>
			
	<!-- vision student login -->
	<div id="vision" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Vision</strong></div></div>
		<div class="modal-body">
		<p>To become an ASEAN Premier State University in 2020.</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>
	
	
				    <!-- mission student login -->
	<div id="mission" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Mission</strong></div></div>
		<div class="modal-body">
		<p>
		The Pangasinan State University in instruction, research, extension, and production commits to develop highly
		principled, morally upright, innovative, and globally competent individuals capable of meeting the needs of
		industry, public service and cuvil society.
		</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>