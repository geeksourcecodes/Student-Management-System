		
    	<div style="overflow:hidden; width:960px; margin:0 auto; padding:0 20px;"> 
                <div class="pix_diapo">

                    <div data-thumb="image/m1.png">
                        <img src="image/m1.png">
                    </div>
                    
                    <div data-thumb="image/m2.jpg">
                        <img src="image/m2.jpg"> 
                    </div>
                    
                    <div data-thumb="image/m3.jpg" data-time="7000">
                        <img src="image/m3.jpg">
                    </div>       
					
                <div data-thumb="image/m4" data-time="7000">
                        <img src="image/m4.jpg">
                    </div>

                <div data-thumb="image/m5.jpg" data-time="7000">
                        <img src="image/m5.jpg">
                    </div>
                    
      
                    
               </div><!-- #pix_diapo -->
               
        </div>
    
    
    </section> 