<?php
include('dbcon.php');
$id=$_GET['id'];
$del = "delete from expenses where expenses_id='$id'";
$dc = $conn ->query($del);

header('location:expenses.php');
?>