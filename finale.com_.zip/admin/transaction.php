<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('dbcon.php'); ?>

    <div class="container">
		<div class="margin-top">
			<div class="row">	
				<?php include('head.php'); ?>
			<div class="span2">		
               <?php include('dashboard_sidebar.php'); ?>
			</div>	
			<div class="span12" style="max-width:948px	;margin-left: 50px;max-height: 100%">
			  				<ul class="nav nav-tabs nav-stacked" style="width: 160px">
											<li>
											<a href="#add_transaction" data-toggle="modal" ><i class="icon-plus icon-large"></i>&nbsp;<strong>Add Transaction</strong></a>
											</li>
										</ul>
										
										 
     <!-- Modal add user -->
	<?php include('modal_add_transaction.php'); ?>
										
			
			<div class="span10">
			
			
					
                            <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
                                <div class="alert alert-info">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Expenses List</strong>
                                </div>
                                <thead>
                                    <tr>
                                        <th>Detail</th>
                                        <th>Price</th>                                                                
                                        <th>Course</th>
                                        <th>Term</th>                                                                
                                        <th>Deadline</th>
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php $expenses_query="select * from expenses";
                                  $cor = $conn ->query($expenses_query);

									while($row=mysqli_fetch_array($cor)){
									$id=$row['expenses_id']; ?>
									 <tr class="del<?php echo $id ?>">
                                    <td><?php echo $row['detail']; ?></td> 
                                    <td><?php echo $row['price']; ?></td> 
									<td><?php echo $row['course']; ?></td> 
									<td><?php echo $row['term']; ?></td> 
                                    <td><?php echo $row['deadline']; ?></td> 
                                    
									
									     <!-- Modal edit user -->
								
                                    </tr>
									<?php } ?>
                           
                                </tbody>
                            </table>
                            </div>
			</div>
			</div>
		</div>
    </div>
<?php include('footer.php') ?>