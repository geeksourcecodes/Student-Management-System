<?php
include('dbcon.php');
$id=$_GET['id'];
$del = "delete from transaction where transaction_id='$id'";
$dc = $conn ->query($del);

header('location:transaction.php');
?>