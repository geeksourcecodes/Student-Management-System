
<ul id="da-thumbs" class="da-thumbs">
					<li>
						<a href="">
							<img src="images/3.jpg" />
							<div><center><span>Information<br>Technology</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/4.jpg" />
							<div><center><span>Business<br>Administration</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/5.jpg" />
							<div><center><span>Office<br>Administration</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/6.jpg" />
							<div><center><span>Hospitality<br>Management</span></div>
						</a>
					</li>
</ul>
					