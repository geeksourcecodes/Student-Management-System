<?php include('header.php'); ?>

    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head1.php'); ?>

				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
					<?php include('slider.php'); ?>
				</div>
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
				<?php include('thumbnail.php'); ?>
				
					
					<div class="text_content">
					<div class="abc">
					<!-- text content -->
					<h4>Vision</h4>
					<hr>
					<p>
					To become an ASEAN Premier State University in 2020.
					</p>
					<hr>
					<h4>Mission</h4>
					<hr>
					<p>
		The Pangasinan State University through instruction, research, extension, and production commits to develop
		highly principled, morally upright, innovative, and globally competent individuals capable of meeting 
		the needs of industry, public service, and civil society.
					</p>
					<hr>
					</div>
					</div>
					<!-- end content -->
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>