<div class="grading">
		
			<div class="span12"><strong><h4><i class="icon-file"></i>&nbsp;Grading System</h4></strong></div>
			<div class="span3">
			<div class="grade_bg">
			<p>1.00&nbsp;&nbsp;&nbsp;98.00 - 100.00% <span class="Excellent">Passed</span></p>
			<p>1.25&nbsp;&nbsp;&nbsp;95.00 - 97.00%  <span class="Excellent">Passed</span></p>
			<p>1.50&nbsp;&nbsp;&nbsp;92.00 - 94.00%  <span class="Excellent">Passed</span></p>
			<p>1.75&nbsp;&nbsp;&nbsp;89.00 - 91.00%  <span class="Excellent">Passed</span></p>
			</div>
			</div>
			<div class="span3">
			<div class="grade_bg">
			<p>2.00&nbsp;&nbsp;&nbsp;89.00 - 88.00% <span class="Excellent">Passed</span></p>
			<p>2.25&nbsp;&nbsp;&nbsp;83.00 - 85.00% <span class="Excellent">Passed</span></p>
			<p>2.50&nbsp;&nbsp;&nbsp;80.00 - 82.00% <span class="Excellent">Passed</span></p>
			<p>2.75&nbsp;&nbsp;&nbsp;77.00 - 79.00% <span class="Excellent">Passed</span></p>
			
			</div>
			</div>
			<div class="span3">
			<div class="grade_bg">
			<p>3.00&nbsp;&nbsp;&nbsp;75.00 - 76.00% <span class="Excellent">Passed</span></p>
			<p>5.00&nbsp;&nbsp;&nbsp;0 - 74.00%  <span class="failed">Failed</span></p>
			<p>INC&nbsp;&nbsp;&nbsp;0 - 0%  <span class="fair">Incomplete</span></p>
			<p>DRP&nbsp;&nbsp;&nbsp;0 - 0% <span class="drop">Officially Dropped</span></p>
			</div>
			</div>
			
	
		
			
</div>

	